package com.marufeb.model;

public enum Variations {
    FIRST, SECOND, THIRD
}
