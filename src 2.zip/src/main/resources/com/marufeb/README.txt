INDEPENDENT PACKAGE: model

GRASP classes:
Game, GameEngine

SOLID classes:
Card, Stack

